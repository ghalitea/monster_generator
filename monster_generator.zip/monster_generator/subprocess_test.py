import subprocess

subprocess.run(['echo','hello world'])